window.onsubmit=validateForm;

function validateForm() {
	var first = document.getElementById("firstname").value;
    var last = document.getElementById("lastname").value;
	var p1 = document.getElementById("phoneFirstPart").value;
	var p2 = document.getElementById("phoneSecondPart").value;
	var p3 = document.getElementById("phoneThirdPart").value;
    var email = document.getElementById("email").value;
	var age = document.getElementById("age").value;
	var heightFeet = document.getElementById("heightFeet").value
	var heightInches = document.getElementById("heightInches").value;
	var weight = document.getElementById("weight").value;
	//returns an array of values
    var check1= document.getElementById("check1").checked;
	var check2= document.getElementById("check2").checked;
	var check3= document.getElementById("check3").checked;
	var check4= document.getElementById("check4").checked;
	var check5= document.getElementById("check5").checked;
	var radio1= document.getElementById("time1").checked;
	var radio2= document.getElementById("time2").checked;
	var radio3= document.getElementById("time3").checked;
	var radio4= document.getElementById("time4").checked;
	var radiobuttons = [radio1,radio2,radio3,radio4];
	var studyA = document.getElementById("firstFourDigits").value;
	var studyB = document.getElementById("secondFourDigits").value;
	
	
	//console.log("P1 is " + p1);
	//validate numbers
	if (isNaN(p1) || isNaN(p2) || isNaN(p3)) {
        alert("Phone numbers need to be numbers: Invalid phone Number");
		return false;
    }else if(p1.length != 3 || p2.length != 3 || p3.length != 4){
		alert("Invalid Phone Number");
		return false;
    }
	
	 //Your program must verify (using JavaScript) that at least one condition ("High Blood Pressure","Diabetes", "Glaucoma", "Asthma", "None") has been selected
    //"No conditions selected"
    var c=false;
	if (check1 == true|| check2 == true || check3 == true || check4 == true || check5 == true) {
		if (check5 == true && (check1 == true || check2 == true || check3 == true || check4 == true)) {
            alert("Invalid conditions selected");
			return false;
        }
        c = true;
    }
    if(c == false){
		alert("No conditions selected");
		return false;
	}
	
	 //Your program must verify (using JavaScript) that at least one time period ("Never", "Less than a year", "One to two years", "More than two years") has been selected
    //"No time period selected"
    
	var r=false;
	for (var i =0; i <radiobuttons.length; i++) {
		if (radiobuttons[i] == true) {
            r =true;
			break;
        }
    }
    if(r == false){
		alert("No time period selected");
		return false;
	}
	
	  //Your program must verify (using JavaScript) that a valid study id has been provided. Valid ids have the following format A### B### where # is a digit.
    //Your program will generate the message "Invalid study id"
	console.log("studyA is " + studyA);
	if (validateID(studyA,studyB) == false) {
		alert("Invalid study id");
        return false;
    }
	return true;
}


function validateID (a,b) {
	var result = true;
	
    if (a.length == 4 && b.length == 4) {
		console.log("studyA first is " + a.charAt(0));
		if (a.charAt(0) === 'A') {
            for (var ind = 1; ind < a.length; ind++) {
				if (isNaN(a.charAt(ind))) {
                    result = false;
					break;
                }
			}
        }else {
			result = false;
		}
		if (b.charAt(0) === 'B') {
            for (var other = 1; other < b.length; other++) {
				if (isNaN(b.charAt(other))) {
                    result = false;
					break;
                }
			}
        }else {
			result = false;
		}
    }else {
		result = false;
	}
	return result;
}